function togglePost(index) {
    var content = document.getElementById('postContent' + index);
    var readMore = document.getElementById('readMore' + index);
    if (content.classList.contains('hidden')) {
        content.classList.remove('hidden');
        readMore.style.display = 'none';
    } else {
        content.classList.add('hidden');
        readMore.style.display = 'block';
    }
}