$(document).ready(function(){
    $('#submitButton').click(function(event){
        event.preventDefault();
        var formData = $('#registroForm').serialize();

        $.ajax({
            type: 'POST',
            url: 'servicios/process_register.php',
            data: formData,
            success: function(response){
                $('#mensaje').html(response);
            }
        });
    });
});