$(document).ready(function(){
    $('#submitButton').click(function(event){
        event.preventDefault();
        var formData = $('#registroForm').serialize();

        $.ajax({
            type: 'POST',
            url: 'servicios/process_login.php',
            data: formData,
            success: function(response){
                if (response.trim() === "<p class='text-red-500'>Contraseña incorrecta.</p>") {
                    $('#mensaje').html(response);
            }
            }
        });
    });
});