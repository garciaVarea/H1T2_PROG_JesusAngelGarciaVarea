<?php
include 'conn_test.php';

// Verificar si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener el correo electrónico y la contraseña enviados desde el formulario
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Consultar si el usuario existe en la base de datos
    $consulta = $conexion->prepare("SELECT id, contrasena FROM usuarios WHERE email = ?");
    $consulta->bind_param("s", $email);
    $consulta->execute();
    $consulta->store_result();

    // Si se encontró algún resultado, significa que el usuario existe
    if ($consulta->num_rows > 0) {
        // Obtener la contraseña almacenada en la base de datos
        $consulta->bind_result($id, $password_hash);
        $consulta->fetch();

        // Verificar si la contraseña enviada coincide con la contraseña almacenada
        if (password_verify($password, $password_hash)) {
            // Iniciar la sesión
            session_start();

            // Establecer las variables de sesión
            $_SESSION['id'] = $id;
            $_SESSION['email'] = $email;
            $_SESSION['logged_in'] = true;

            // Establecer una cookie de sesión
            setcookie('session_id', session_id(), time() + (86400 * 30), '/'); // La cookie expira en 30 días

            // Redirigir al usuario a otra página
            header("Location: ../blog.php");
            exit(); // Asegúrate de salir del script después de la redirección
        } else {
            echo "<p class='text-red-500'>Contraseña incorrecta.</p>";
        }
    } else {
        echo "<p class='text-red-500'>Usuario no encontrado.</p>";
        header("refresh:1;url=../login.php");
        exit(); // Asegúrate de salir del script después de la redirección
    }

    // Cerrar la consulta
    $consulta->close();
}

// Cerrar la conexión a la base de datos
$conexion->close();
?>



