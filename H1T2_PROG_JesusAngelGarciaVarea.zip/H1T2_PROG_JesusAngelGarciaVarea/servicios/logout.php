<?php

// Iniciar la sesión
session_start();

// Destruir la sesión
session_destroy();
// Eliminar la cookie de sesión
setcookie('session_id', '', time() - 3600, '/');

echo '<script>window.setTimeout(function() { window.location.href = "../index.php"; }, 1000);</script>';
?>

