<?php

// Crear conexión a la base de datos
$conexion = new mysqli('localhost', 'root', '', 'blog');

// Verificar si hay errores de conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

//echo "Conexión exitosa a la base de datos!";
?>