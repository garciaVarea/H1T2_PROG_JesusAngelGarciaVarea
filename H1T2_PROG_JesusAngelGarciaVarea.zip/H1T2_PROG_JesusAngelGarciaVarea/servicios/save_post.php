<?php
include 'conn_test.php'; // Incluir el archivo de conexión

// Verificar si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $email = $_POST["email"];
    $title = $_POST["title"];
    $content = $_POST["content"];
    $publish_date = $_POST["publish_date"];

    // Procesar la imagen
    if (isset($_FILES["image"]) && $_FILES["image"]["size"] > 0) {
        $image = $_FILES["image"];
        $image_content = file_get_contents($image["tmp_name"]); // Obtener el contenido de la imagen
        $image_content = base64_encode($image_content); // Convertir el contenido a base64 para guardarlo en un campo TEXT
    }

    // Consulta SQL para obtener el ID del usuario
    $sql_user_id = "SELECT id FROM usuarios WHERE email = ?";

    // Preparar la consulta
    $stmt_user_id = $conexion->prepare($sql_user_id);

    // Enlazar los parámetros
    $stmt_user_id->bind_param("s", $email);

    // Ejecutar la consulta
    $stmt_user_id->execute();

    // Obtener el resultado
    $result_user_id = $stmt_user_id->get_result();

    // Verificar si se encontró el usuario
    if ($result_user_id->num_rows > 0) {
        // Obtener el ID del usuario
        $row = $result_user_id->fetch_assoc();
        $id_usuario = $row['id'];

        // Consulta SQL para insertar los datos en la tabla
        $sql = "INSERT INTO publicaciones (id_usuario, email, title, content, publish_date, img) VALUES (?, ?, ?, ?, ?, ?)";

        // Preparar la consulta
        $stmt = $conexion->prepare($sql);

        // Enlazar los parámetros
        $stmt->bind_param("isssss", $id_usuario, $email, $title, $content, $publish_date, $image_content);

        // Ejecutar la consulta
        $stmt->execute();

        // Verificar si la inserción fue exitosa
        if ($stmt->affected_rows > 0) {
            echo "Publicación creada exitosamente.";
            // Redirigir al usuario a la página de inicio
            echo "<script>setTimeout(function(){ window.location.href = '../blog.php'; }, 1000);</script>";
        } else {
            echo "Error al crear la publicación.";
        }

        // Cerrar la conexión
        $stmt->close();
    } else {
        echo "Error: No se encontró el usuario.";
    }

    // Cerrar la conexión
    $stmt_user_id->close();
    $conexion->close();
}
?>





