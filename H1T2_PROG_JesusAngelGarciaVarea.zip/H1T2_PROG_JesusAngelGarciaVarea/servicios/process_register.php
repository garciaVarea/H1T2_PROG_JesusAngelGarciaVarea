<?php
include 'conn_test.php';
// Verificar si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conectar a la base de datos

    // Verificar la conexión
    if ($conexion->connect_error) {
        die("Error de conexión: " . $conexion->connect_error);
    }

    // Obtener el correo electrónico enviado desde el formulario
    $email = $_POST["email"];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<p class='text-red-500'>El formato del correo electrónico no es válido.</p>";
        exit;
    }

    // Consultar si el correo electrónico ya está registrado
    $consulta = $conexion->prepare("SELECT email FROM usuarios WHERE email = ?");
    $consulta->bind_param("s", $email);
    $consulta->execute();
    $consulta->store_result();

    // Si se encontró algún resultado, significa que el correo ya está registrado
    if ($consulta->num_rows > 0) {
        echo "<p class='text-red-500'>El correo electrónico ya está registrado.</p>";
    } else {
        // Si no se encontraron resultados, el correo no está registrado y se puede proceder con el registro
        // Aquí deberías escribir el código para insertar el nuevo usuario en la base de datos
        $password = $_POST["password"];

        // Aplicar el hash a la contraseña
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        // Consulta para insertar el nuevo usuario en la base de datos
        $consulta_insertar = $conexion->prepare("INSERT INTO usuarios (email, contrasena) VALUES (?, ?)");
        $consulta_insertar->bind_param("ss", $email, $password_hash);

        // Ejecutar la consulta
        if ($consulta_insertar->execute()) {
            echo "<p class='text-green-500'>¡Registro exitoso! Inicie sesión</p>";
            // Redirigir después de 3 segundos
            header("refresh:3;url=login.php");
            exit;
        } else {
            echo "<p class='text-red-500'>Error al registrar el usuario.</p>";
        }

    }

    // Cerrar la conexión a la base de datos
    $conexion->close();
}
?>

