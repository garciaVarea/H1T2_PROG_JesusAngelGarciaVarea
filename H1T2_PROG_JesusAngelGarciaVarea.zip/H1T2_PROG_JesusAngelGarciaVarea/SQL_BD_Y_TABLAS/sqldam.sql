create database blog;
SELECT USER(), CURRENT_USER(), @@hostname;
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE publicaciones (
    id_post INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    email VARCHAR(255) NOT NULL,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    publish_date DATE NOT NULL,
    img TEXT, 
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
);