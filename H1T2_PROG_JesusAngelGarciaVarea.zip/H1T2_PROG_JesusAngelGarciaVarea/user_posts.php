<?php
include 'servicios/conn_test.php'; // Incluir el archivo de conexión

// Iniciar la sesión
session_start();

// Verificar si el usuario ha iniciado sesión
if (isset($_SESSION['email'])) {
    // Obtener el correo electrónico del usuario conectado
    $email = $_SESSION['email'];

    // Consulta SQL para seleccionar todos los posts del usuario actual
    $sql = "SELECT * FROM publicaciones WHERE email = ?";

    // Preparar la consulta
    $stmt = $conexion->prepare($sql);

    // Enlazar los parámetros
    $stmt->bind_param("s", $email);

    // Ejecutar la consulta
    $stmt->execute();

    // Obtener el resultado
    $result = $stmt->get_result();

    // Verificar si hay resultados
    if ($result->num_rows > 0) {
        // Crear un array para almacenar los posts
        $blog_posts = array();

        // Iterar sobre los resultados y guardarlos en el array
        while ($row = $result->fetch_assoc()) {
            // Decodificar la imagen base64
            $row['img'] = base64_decode($row['img']);
            $blog_posts[] = $row;
        }
    } else {
        // Si no hay resultados, mostrar un mensaje de que no hay posts
        $blog_posts = array();
        echo "No se encontraron publicaciones.";
    }

    // Cerrar la consulta
    $stmt->close();
} else {
    // Si el usuario no ha iniciado sesión, redirigirlo a la página de inicio de sesión
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Explicación de Lenguajes de Programación</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
<nav class="bg-white dark:bg-gray-900 fixed w-full z-20 top-0 start-0 border-b border-gray-200 dark:border-gray-600">
    <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
        <a href="" class="flex items-center space-x-3 rtl:space-x-reverse"> <!--  logo página  -->
            <img src="img/logo.png" class="h-8" alt="Flowbite Logo"><!--  img  -->
            <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">Blog</span>
        </a>
        <div class="flex md:order-2 space-x-3 md:space-x-0 rtl:space-x-reverse">
            <?php

            // Verificar si el usuario ha iniciado sesión
            if (isset($_COOKIE['session_id'])) {
                // El usuario ha iniciado sesión, mostrar el correo electrónico del usuario en el enlace
                echo '<a class="mr-2 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">' . $_SESSION['email'] . '</a>';
            } else {
                // Si el usuario no ha iniciado sesión, mostrar el enlace de inicio de sesión normal
                echo '<a href="login.php" class="mr-2 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Inicia sesión</a>';
            }

            // Verificar si el usuario ha iniciado sesión
            if (isset($_COOKIE['session_id'])) {
                // El usuario ha iniciado sesión, mostrar el enlace para cerrar sesión
                echo '<a href="servicios/logout.php" class="text-black bg-white border border-blue-700 hover:bg-blue-700 hover:text-white focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 dark:text-white dark:hover:text-white">Cerrar sesión</a>';
            } else {
                // Si el usuario no ha iniciado sesión, mostrar el enlace de registro normal
                echo '<a href="registro.php" class="text-black bg-white border border-blue-700 hover:bg-blue-700 hover:text-white focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 dark:text-white dark:hover:text-white">Registrarse</a>';
            }
            ?>

            <button data-collapse-toggle="navbar-sticky" type="button" class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-sticky" aria-expanded="false">
                <span class="sr-only">Open main menu</span>
                <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 1h15M1 7h15M1 13h15"/>
                </svg>
            </button>
        </div>
        <div class="items-center justify-between hidden w-full md:flex md:w-auto md:order-1" id="navbar-sticky">
            <ul class="flex flex-col p-4 md:p-0 mt-4 font-medium border border-gray-100 rounded-lg bg-gray-50 md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0 md:bg-white dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
                <li>
                    <a href="index.php" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-blue-700 md:p-0 md:dark:hover:text-blue-500 dark:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700" aria-current="page">Inicio</a>
                </li>
                <li>
                    <a href="blog.php" class="block py-2 px-3 text-white bg-blue-700 rounded md:bg-transparent md:text-blue-700 md:p-0 md:dark:text-blue-500">Blog</a>
                </li>
                <li>
                    <a href="user_posts.php" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-blue-700 md:p-0 md:dark:hover:text-blue-500 dark:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700">Mis post</a>
                </li>
            </ul>
        </div>
    </div>
    <hr class="menu-divider">
</nav>


<div class="container mx-auto mt-20 flex justify-center">
    <div class="w-3/4 bg-white p-6 rounded-lg shadow-lg">
        <h1 class="text-2xl font-bold mb-4">Mis post</h1>
        <?php foreach ($blog_posts as $index => $post) { ?>
            <div class="mb-6 transition duration-300 ease-in-out transform hover:shadow-lg">
                <h2 class="text-xl font-semibold mb-2 cursor-pointer" onclick="togglePost(<?php echo $post["title"]; ?>)"><?php echo $post["title"]; ?></h2>
                <div id="postContent<?php echo $index; ?>" class="hidden">
                    <p><?php echo $post["content"]; ?></p>
                    <?php if ($post["img"]) { ?>
                        <img src="data:image/jpeg;base64,<?php echo base64_encode($post["img"]); ?>" alt="Imagen del post" class="mb-2 w-full md:w-1/3">
                    <?php } ?>
                    <p class="text-sm text-gray-500">Publicado por: <?php echo $post["email"]; ?> - Fecha: <?php echo $post["publish_date"]; ?></p>
                    <a href="javascript:void(0)" onclick="togglePost(<?php echo $index; ?>)" class="text-blue-500 cursor-pointer">Cerrar</a>
                </div>
                <div id="readMore<?php echo $index; ?>" class="text-blue-500 cursor-pointer" onclick="togglePost(<?php echo $index; ?>)">Leer más</div>
            </div>
        <?php } ?>
    </div>

    <div class="w-1/4 ml-5 bg-white p-4 rounded-lg shadow-lg text-center">
        <h2 class="text-lg font-bold mb-2">Enlaces</h2>
        <ul>
            <li><a href="blog.php" class="text-blue-500 hover:underline">Ultimos posts</a></li>
            <hr>
            <li><a href="user_posts.php" class="text-blue-500 hover:underline">Mis posts</a></li>
            <hr>
            <li><a href="get_post.php" class="text-blue-500 hover:underline">Crear un nuevo post</a></li>
            <hr>
            <li><a href="mod_delete_post.php" class="text-blue-500 hover:underline">Modificar/eliminar post</a></li>
            <hr>
            <li><a href="rss.php" class="text-blue-500 hover:underline">Siguenos en redes sociales</a></li>
            <hr>
        </ul>
    </div>
</div>
<script src="js/blog.js"></script>
</body>
</html>