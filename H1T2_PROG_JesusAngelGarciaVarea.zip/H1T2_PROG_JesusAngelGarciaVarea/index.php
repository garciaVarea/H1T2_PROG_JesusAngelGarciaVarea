<?php
// Función para establecer la cookie
function setCookieWithIP($name, $value, $expiry) {
    setcookie($name, $value, time() + $expiry, '/');
}

// Obtener la dirección IP del cliente
$ip = $_SERVER['REMOTE_ADDR'];

// Guardar la dirección IP en una cookie durante 30 días
setCookieWithIP('ip_equipo', $ip, 30);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Explicación de Lenguajes de Programación</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
<nav class="bg-white dark:bg-gray-900 fixed w-full z-20 top-0 start-0 border-b border-gray-200 dark:border-gray-600">
    <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
        <a href="" class="flex items-center space-x-3 rtl:space-x-reverse"> <!--  logo página  -->
            <img src="img/logo.png" class="h-8" alt="Flowbite Logo"><!--  img  -->
            <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">Blog</span>
        </a>
        <div class="flex md:order-2 space-x-3 md:space-x-0 rtl:space-x-reverse">
            <?php
            // Iniciar la sesión
            session_start();

            // Verificar si el usuario ha iniciado sesión
            if (isset($_COOKIE['session_id'])) {
                // El usuario ha iniciado sesión, mostrar el correo electrónico del usuario en el enlace
                echo '<a class="mr-2 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">' . $_SESSION['email'] . '</a>';
            } else {
                // Si el usuario no ha iniciado sesión, mostrar el enlace de inicio de sesión normal
                echo '<a href="login.php" class="mr-2 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Inicia sesión</a>';
            }

            // Verificar si el usuario ha iniciado sesión
            if (isset($_COOKIE['session_id'])) {
                // El usuario ha iniciado sesión, mostrar el enlace para cerrar sesión
                echo '<a href="servicios/logout.php" class="text-black bg-white border border-blue-700 hover:bg-blue-700 hover:text-white focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 dark:text-white dark:hover:text-white">Cerrar sesión</a>';
            } else {
                // Si el usuario no ha iniciado sesión, mostrar el enlace de registro normal
                echo '<a href="registro.php" class="text-black bg-white border border-blue-700 hover:bg-blue-700 hover:text-white focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 dark:text-white dark:hover:text-white">Registrarse</a>';
            }
            ?>
            <button data-collapse-toggle="navbar-sticky" type="button" class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-sticky" aria-expanded="false">
                <span class="sr-only">Open main menu</span>
                <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 1h15M1 7h15M1 13h15"/>
                </svg>
            </button>
        </div>
        <div class="items-center justify-between hidden w-full md:flex md:w-auto md:order-1" id="navbar-sticky">
            <ul class="flex flex-col p-4 md:p-0 mt-4 font-medium border border-gray-100 rounded-lg bg-gray-50 md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0 md:bg-white dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
                <li>
                    <a href="index.php" class="block py-2 px-3 text-white bg-blue-700 rounded md:bg-transparent md:text-blue-700 md:p-0 md:dark:text-blue-500" aria-current="page">Inicio</a>
                </li>
                <li>
                    <a href="blog.php" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-blue-700 md:p-0 md:dark:hover:text-blue-500 dark:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700">Blog</a>
                </li>
                <li>
                    <a href="user_posts.php" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-blue-700 md:p-0 md:dark:hover:text-blue-500 dark:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700">Mis post</a>
                </li>
            </ul>
        </div>
    </div>
    <hr class="menu-divider">
</nav>
<div class="container mx-auto p-4 mt-24"> <!-- Aquí agregamos mt-24 para un espacio desde la parte superior -->
    <!-- Línea separadora -->

    <!-- contenido -->
    <h1 class="text-3xl font-bold mb-4">Diferencias entre lenguajes de programación</h1>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">









        <div class="p-4 bg-white rounded shadow-md"><!-- POO -->
            <h2 class="text-xl font-bold mb-2">Orientada a Objetos</h2>
            <p>Los lenguajes de programación orientada a objetos se basan en la idea de encapsular datos y métodos dentro de objetos. Se enfocan en la interacción entre estos objetos y la herencia de características.</p>
            <p><i>(Estaremos utilizando python en los ejemplos)</i></p>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Clases y objetos</h3>
            <p>Las clases y los objetos son los bloques de construcción fundamentales de la programación orientada a objetos. Una clase es una plantilla para crear objetos, y un objeto es una instancia de una clase.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <div class="text-sm font-mono">
                    <p>
                        # Definición de la clase<br>
                        class Persona:<br>
                        &emsp;def __init__(self, nombre, edad):<br>
                        &emsp;&emsp;self.nombre = nombre<br>
                        &emsp;&emsp;self.edad = edad<br><br>

                        &emsp;def saludar(self):<br>
                        &emsp;&emsp;return f"Hola, soy {self.nombre} y tengo {self.edad} años."<br><br>

                        # Crear instancias u objetos de la clase Persona<br>
                        persona1 = Persona("Juan", 30)<br>
                        persona2 = Persona("María", 25)<br><br>

                        # Acceder a los atributos y métodos de los objetos<br>
                        print(persona1.nombre)  # Output: Juan<br>
                        print(persona2.edad)    # Output: 25<br><br>

                        print(persona1.saludar())  # Output: Hola, soy Juan y tengo 30 años.<br>
                        print(persona2.saludar())  # Output: Hola, soy María y tengo 25 años.<br><br>
                    </p>
                    <p>Este código demuestra la definición de una clase Persona con un constructor __init__ y un método saludar. Luego, se crean dos instancias u objetos de la clase Persona y se accede a sus atributos y métodos.</p>
                </div>
            </div>

            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Encapsulación</h3>
            <p>La encapsulación es el proceso de ocultar los detalles internos de un objeto y exponer solo las operaciones que se pueden realizar con él. En la programación orientada a objetos, la encapsulación se logra mediante el uso de modificadores de acceso, como public, private y protected.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    class CuentaBancaria:<br>
                    &emsp;def __init__(self, titular, saldo):<br>
                    &emsp;&emsp;self.__titular = titular  # Atributo privado<br>
                    &emsp;&emsp;self.__saldo = saldo      # Atributo privado<br><br>

                    &emsp;def depositar(self, cantidad):<br>
                    &emsp;&emsp;if cantidad > 0:<br>
                    &emsp;&emsp;&emsp;self.__saldo += cantidad<br><br>

                    &emsp;def retirar(self, cantidad):<br>
                    &emsp;&emsp;if cantidad > 0 and cantidad <= self.__saldo:<br>
                    &emsp;&emsp;&emsp;self.__saldo -= cantidad<br><br>

                    &emsp;def obtener_saldo(self):<br>
                    &emsp;&emsp;return self.__saldo<br><br>


                    # Crear una instancia de CuentaBancaria<br>
                    mi_cuenta = CuentaBancaria("Juan", 1000)<br><br>

                    # Intentar acceder directamente a los atributos privados (generará un error)<br>
                    # print(mi_cuenta.__titular)  # Generará un AttributeError<br><br>

                    # Acceder al saldo a través de un método público<br>
                    print("Saldo actual:", mi_cuenta.obtener_saldo())  # Output: Saldo actual: 1000<br><br>

                    # Realizar una operación de depósito<br>
                    mi_cuenta.depositar(500)<br><br>

                    # Realizar una operación de retiro<br>
                    mi_cuenta.retirar(200)<br><br>

                    # Acceder al saldo actualizado<br>
                    print("Saldo actualizado:", mi_cuenta.obtener_saldo())  # Output: Saldo actualizado: 1300<br><br>

                </p>
                <p>Este código demuestra la encapsulación en acción. Los atributos titular y saldo de la clase CuentaBancaria están marcados como privados y solo se pueden acceder a través de los métodos públicos depositar, retirar y obtener_saldo.</p>
            </div>

            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Abstracción</h3>
            <p>La abstracción es el proceso de identificar las características esenciales de un objeto y eliminar los detalles innecesarios. En la programación orientada a objetos, la abstracción se utiliza para definir las clases y los objetos.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    from abc import ABC, abstractmethod<br><br>

                    # Definición de una clase abstracta<br>
                    class FiguraGeometrica(ABC):<br>
                    &emsp;def __init__(self, nombre):<br>
                    &emsp;&emsp;self.nombre = nombre<br><br>

                    &emsp;@abstractmethod<br>
                    &emsp;def area(self):<br>
                    &emsp;&emsp;pass<br><br>

                    # Definición de una subclase concreta<br>
                    class Cuadrado(FiguraGeometrica):<br>
                    &emsp;def __init__(self, nombre, lado):<br>
                    &emsp;&emsp;super().__init__(nombre)<br>
                    &emsp;&emsp;self.lado = lado<br><br>

                    &emsp;def area(self):<br>
                    &emsp;&emsp;return self.lado ** 2<br><br>

                    # Creación de objetos<br>
                    mi_cuadrado = Cuadrado("Cuadrado", 5)<br><br>

                    # Uso de la abstracción para obtener el área de la figura geométrica<br>
                    print("Área del cuadrado:", mi_cuadrado.area())  # Output: Área del cuadrado: 25
                </p>
                <p>Este código demuestra la abstracción en acción. La clase FiguraGeometrica es una clase abstracta que define un método abstracto area. La subclase Cuadrado hereda de la clase FiguraGeometrica y proporciona una implementación concreta del método area.</p>
            </div>



            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Herencia</h3>
            <p>La herencia es el proceso de crear una nueva clase basada en una clase existente. La nueva clase hereda las características de la clase existente y puede agregar nuevas características o modificar las existentes.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    # Definición de la clase base (superclase)<br>
                    class Animal:<br>
                    &emsp;def __init__(self, nombre):<br>
                    &emsp;&emsp;self.nombre = nombre<br><br>

                    &emsp;def hacer_sonido(self):<br>
                    &emsp;&emsp;return "Haciendo algún sonido"<br><br>

                    # Definición de una subclase que hereda de la clase base (Animal)<br>
                    class Perro(Animal):<br>
                    &emsp;def __init__(self, nombre, raza):<br>
                    &emsp;&emsp;super().__init__(nombre)<br>
                    &emsp;&emsp;self.raza = raza<br><br>

                    &emsp;def hacer_sonido(self):<br>
                    &emsp;&emsp;return "¡Guau!"<br><br>

                    # Definición de otra subclase que hereda de la clase base (Animal)<br>
                    class Gato(Animal):<br>
                    &emsp;def __init__(self, nombre, color):<br>
                    &emsp;&emsp;super().__init__(nombre)<br>
                    &emsp;&emsp;self.color = color<br><br>

                    &emsp;def hacer_sonido(self):<br>
                    &emsp;&emsp;return "¡Miau!"<br><br>

                    # Crear instancias de las subclases<br>
                    mi_perro = Perro("Buddy", "Labrador")<br>
                    mi_gato = Gato("Whiskers", "Blanco")<br><br>

                    # Llamar a métodos de la superclase y subclases<br>
                    print(mi_perro.nombre, "es un", mi_perro.raza)<br>
                    print(mi_perro.hacer_sonido())  # Output: ¡Guau!<br><br>

                    print(mi_gato.nombre, "es de color", mi_gato.color)<br>
                    print(mi_gato.hacer_sonido())   # Output: ¡Miau!<br><br>
                </p>
                <p>Este código demuestra la herencia en acción. Las subclases Perro y Gato heredan de la superclase Animal y pueden agregar sus propias características y comportamientos.</p>
            </div>

            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Polimorfismo</h3>
            <p>El polimorfismo es el proceso de utilizar un objeto de una clase como si fuera un objeto de otra clase. En la programación orientada a objetos, el polimorfismo se logra mediante el uso de clases y métodos abstractos, interfaces y sobrecarga de métodos.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    # Definición de la clase base (superclase)<br>
                    class Animal:<br>
                    &emsp;def hablar(self):<br>
                    &emsp;&emsp;pass<br><br>

                    # Definición de subclases que heredan de la clase base (Animal)<br>
                    class Perro(Animal):<br>
                    &emsp;def hablar(self):<br>
                    &emsp;&emsp;return "¡Guau!"<br><br>

                    class Gato(Animal):<br>
                    &emsp;def hablar(self):<br>
                    &emsp;&emsp;return "¡Miau!"<br><br>

                    # Función que toma un objeto de tipo Animal y llama al método hablar<br>
                    def hacer_sonar_animal(animal):<br>
                    &emsp;print(animal.hablar())<br><br>

                    # Crear instancias de las subclases<br>
                    mi_perro = Perro()<br>
                    mi_gato = Gato()<br><br>

                    # Llamar a la función hacer_sonar_animal con diferentes tipos de animales<br>
                    hacer_sonar_animal(mi_perro)  # Output: ¡Guau!<br>
                    hacer_sonar_animal(mi_gato)   # Output: ¡Miau!<br><br>
                </p>
                <p>Este código demuestra el polimorfismo en acción. La función hacer_sonar_animal toma un objeto de tipo Animal y llama al método hablar, que es implementado de manera diferente en las subclases Perro y Gato.</p>
            </div>








        </div>
        <div class="mt-2 p-4 bg-white rounded shadow-md border border-dark"><!-- POE -->
            <h2 class="text-xl font-bold mb-2">A Eventos</h2>
            <p>Los lenguajes de programación a eventos se centran en responder a eventos del usuario o del sistema. Suelen utilizar callbacks para manejar la ejecución de código en respuesta a acciones específicas.</p>
            <p><i>(En estos ejemplos utilizaremos JavaScript)</i></p>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Concepto de evento</h3>
            <p>Un evento es una señal que indica que algo ha sucedido. En la programación a eventos, los eventos pueden ser generados por el usuario (como hacer clic en un botón) o por el sistema (como recibir un mensaje).</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    // Obtener referencia al botón<br>
                    var boton = document.getElementById('miBoton');<br><br>

                    // Agregar un manejador de eventos para el clic del botón<br>
                    boton.addEventListener('click', function() {<br>
                    &emsp;// Mostrar un mensaje en la consola<br>
                    &emsp;console.log("¡Se hizo clic en el botón!");<br>
                    });<br><br>

                </p>
                <p>Este código agrega un manejador de eventos para el evento de clic en un botón. Cuando el botón se hace clic, se ejecuta la función proporcionada, que muestra un mensaje en la consola del navegador.</p>
            </div>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Modelo de ejecución asíncrona</h3>
            <p>La programación a eventos a menudo se basa en un modelo de ejecución asíncrona, donde el código se ejecuta en respuesta a eventos en lugar de en secuencia. Esto permite que la interfaz de usuario responda a las acciones del usuario de manera rápida y eficiente.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    // Espera a que el DOM esté completamente cargado<br>
                    document.addEventListener('DOMContentLoaded', function() {<br>
                    &emsp;// Obtener referencia al botón<br>
                    &emsp;var boton = document.getElementById('miBoton');<br>
                    <br>
                    &emsp;// Agregar un manejador de eventos para el clic del botón<br>
                    &emsp;boton.addEventListener('click', function() {<br>
                    &emsp;&emsp;// Realizar una solicitud HTTP asíncrona usando fetch<br>
                    &emsp;&emsp;fetch('https://ejemplo.com/datos')<br>
                    &emsp;&emsp;&emsp;.then(function(response) {<br>
                    &emsp;&emsp;&emsp;&emsp;// Convertir la respuesta a formato JSON<br>
                    &emsp;&emsp;&emsp;&emsp;return response.json();<br>
                    &emsp;&emsp;&emsp;})<br>
                    &emsp;&emsp;&emsp;.then(function(data) {<br>
                    &emsp;&emsp;&emsp;&emsp;// Actualizar la interfaz de usuario con los datos recibidos<br>
                    &emsp;&emsp;&emsp;&emsp;document.getElementById('resultado').innerText = data.valor;<br>
                    &emsp;&emsp;&emsp;})<br>
                    &emsp;&emsp;&emsp;.catch(function(error) {<br>
                    &emsp;&emsp;&emsp;&emsp;// Manejar errores<br>
                    &emsp;&emsp;&emsp;&emsp;console.error('Error al obtener los datos:', error);<br>
                    &emsp;&emsp;&emsp;});<br>
                    &emsp;});<br>
                    });

                </p>
                <p>Este código espera a que el DOM esté completamente cargado antes de agregar un manejador de eventos para el clic de un botón. Cuando se hace clic en el botón, se realiza una solicitud HTTP asíncrona usando fetch y se actualiza la interfaz de usuario con los datos recibidos.</p>
            </div>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Gestión de eventos</h3>
            <p>La gestión de eventos es el proceso de definir y manejar eventos en una aplicación. En la programación a eventos, los eventos pueden ser generados por el usuario (como hacer clic en un botón) o por el sistema (como recibir un mensaje).</p>
            <p class="text-sm font-mono">
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                // Obtener referencia al botón<br>
                var boton = document.getElementById('boton');<br><br>

                // Agregar un manejador de eventos para el clic del botón<br>
                boton.addEventListener('click', function() {<br>
                &emsp;// Generar un color aleatorio en formato hexadecimal<br>
                &emsp;var color = '#' + Math.floor(Math.random()*16777215).toString(16);<br><br>

                &emsp;// Cambiar el color de fondo de la página<br>
                &emsp;document.body.style.backgroundColor = color;<br>
                });<br><br>
                </p>
                <p>Este código agrega un manejador de eventos para el evento de clic en un botón. Cuando el botón se hace clic, se ejecuta la función proporcionada, que genera un color aleatorio en formato hexadecimal y cambia el color de fondo de la página.</p>
            </div>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Callback</h3>
            <p>Un callback es una función que se pasa como argumento a otra función y se llama dentro de esa función. En la programación a eventos, los callbacks se utilizan para manejar la ejecución de código en respuesta a eventos específicos.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    // Definimos una función llamada calcular que toma dos números y una función de callback<br>
                    function calcular(num1, num2, callback) {<br>
                    &emsp;// Realizamos una operación matemática (en este caso, la suma)<br>
                    &emsp;var resultado = num1 + num2;<br>
                    &emsp;// Llamamos a la función de callback y le pasamos el resultado como argumento<br>
                    &emsp;callback(resultado);<br>
                    }<br><br>

                    // Definimos una función de callback que simplemente muestra el resultado en la consola<br>
                    function mostrarResultado(resultado) {<br>
                    &emsp;console.log("El resultado es: " + resultado);<br>
                    }<br><br>

                    // Llamamos a la función calcular y le pasamos dos números y la función de callback<br>
                    calcular(5, 3, mostrarResultado); // Output: El resultado es: 8<br>
                </p>
                <p>La función calcular toma dos números y una función de callback, realiza una operación matemática y luego llama a la función de callback con el resultado como argumento.</p>
            </div>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Programación reactiva</h3>
            <p>La programación reactiva es un paradigma de programación que se centra en la propagación de cambios y la gestión de eventos. En la programación a eventos, la programación reactiva se utiliza para crear aplicaciones que responden de manera eficiente a los eventos del usuario o del sistema.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    // Creamos un observable que emite valores cada segundo<br>
                    const observable = setInterval(() => {<br>
                    &emsp;console.log(new Date());<br>
                    }, 1000);<br><br>

                    // Después de 5 segundos, nos desuscribimos del observable<br>
                    setTimeout(() => {<br>
                    &emsp;clearInterval(observable);<br>
                    }, 5000);
                </p>
                <p>Creamos un observable que emite valores cada segundo y luego nos desuscribimos del observable después de 5 segundos.</p>
            </div>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Manejo de concurrencia</h3>
            <p>El manejo de concurrencia es el proceso de gestionar múltiples tareas que se ejecutan simultáneamente. En la programación a eventos, el manejo de concurrencia se utiliza para garantizar que las tareas se ejecuten de manera eficiente y sin bloquear la interfaz de usuario.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    // Realizar una solicitud HTTP asíncrona usando fetch<br>
                    fetch('https://ejemplo.com/datos')<br>
                    &emsp;.then(function(response) {<br>
                    &emsp;&emsp;// Convertir la respuesta a formato JSON<br>
                    &emsp;&emsp;return response.json();<br>
                    &emsp;})<br>
                    &emsp;.then(function(data) {<br>
                    &emsp;&emsp;// Actualizar la interfaz de usuario con los datos recibidos<br>
                    &emsp;&emsp;document.getElementById('resultado').innerText = data.valor;<br>
                    &emsp;})<br>
                    &emsp;.catch(function(error) {<br>
                    &emsp;&emsp;// Manejar errores<br>
                    &emsp;&emsp;console.error('Error al obtener los datos:', error);<br>
                    &emsp;});
                </p>
                <p>Este código realiza una solicitud HTTP asíncrona usando fetch y actualiza la interfaz de usuario con los datos recibidos. La gestión de concurrencia se maneja mediante el uso de promesas y el método then.</p>
            </div>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Escalabilidad y rendimiento</h3>
            <p>La escalabilidad y el rendimiento son aspectos críticos de la programación a eventos. Las aplicaciones a eventos deben ser capaces de manejar grandes volúmenes de eventos y responder de manera eficiente a ellos para garantizar una experiencia de usuario fluida.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    // Crear un servidor HTTP que escuche en el puerto 3000<br>
                    const servidor = http.createServer((solicitud, respuesta) => {<br>
                    &emsp;// Manejar la solicitud y enviar una respuesta<br>
                    &emsp;respuesta.end('¡Hola, mundo!');<br>
                    });<br><br>

                    // Escuchar en el puerto 3000<br>
                    servidor.listen(3000, () => {<br>
                    &emsp;console.log('El servidor está escuchando en el puerto 3000');<br>
                    });
                </p>
                <p>Este código crea un servidor HTTP que escucha en el puerto 3000 y maneja las solicitudes de manera eficiente para garantizar un rendimiento óptimo.</p>
            </div>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Librerías y frameworks</h3>
            <p>Las librerías y frameworks son herramientas fundamentales en la programación a eventos. Estas herramientas proporcionan funcionalidades predefinidas para manejar eventos, gestionar la concurrencia y garantizar un rendimiento óptimo.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    // Importar la librería de manejo de eventos<br>
                    importar { EventEmitter } de 'eventos';<br><br>

                    // Crear un nuevo emisor de eventos<br>
                    const emisor = nuevo EventEmitter();<br><br>

                    // Agregar un manejador de eventos para el evento 'clic'<br>
                    emisor.on('clic', () => {<br>
                    &emsp;console.log('Se hizo clic en el botón');<br>
                    });<br><br>

                    // Emitir el evento 'clic'<br>
                    emisor.emit('clic');
                </p>
                <p>Este código importa la librería de manejo de eventos, crea un nuevo emisor de eventos, agrega un manejador de eventos para el evento 'clic' y emite el evento 'clic'.</p>
            </div>
        </div>

        <div class="mt-2 p-4 bg-white rounded shadow-md border border-dark"> <!-- PP -->
            <h2 class="text-xl font-bold mb-2">Procedimentales</h2>
            <p>Los lenguajes de programación procedimentales se basan en la ejecución secuencial de instrucciones. Utilizan procedimientos o funciones para estructurar y reutilizar el código, pero no tienen concepto de objetos.</p>
            <p><i>(En estos ejemplos utilizaremos C)</i></p>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Funciones y procedimientos</h3>
            <p>Las funciones y procedimientos son bloques de código que realizan una tarea específica. En la programación procedimental, se utilizan para estructurar y reutilizar el código, así como para dividir un programa en partes más pequeñas y manejables.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    // Definición de una función que suma dos números<br>
                    int sumar(int a, int b) {<br>
                    &emsp;return a + b;<br>
                    }<br><br>

                    // Definición de un procedimiento que imprime un mensaje<br>
                    void imprimir_mensaje() {<br>
                    &emsp;printf("¡Hola, mundo!\n");<br>
                    }<br><br>

                    // Llamada a la función sumar y al procedimiento imprimir_mensaje<br>
                    int resultado = sumar(5, 3);<br>
                    imprimir_mensaje();<br>
                </p>
                <p>Este código demuestra la definición y llamada de una función que suma dos números y un procedimiento que imprime un mensaje.</p>
            </div>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Estructuras de control</h3>
            <p>Las estructuras de control son bloques de código que permiten controlar el flujo de ejecución de un programa. En la programación procedimental, se utilizan para tomar decisiones, repetir tareas y manejar errores.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    // Estructura de control if-else para tomar decisiones<br>
                    int edad = 18;<br>
                    if (edad >= 18) {<br>
                    &emsp;printf("Eres mayor de edad\n");<br>
                    } else {<br>
                    &emsp;printf("Eres menor de edad\n");<br>
                    }<br><br>

                    // Estructura de control for para repetir tareas<br>
                    for (int i = 0; i < 5; i++) {<br>
                    &emsp;printf("Iteración %d\n", i);<br>
                    }<br><br>

                    // Estructura de control try-catch para manejar errores<br>
                    try {<br>
                    &emsp;// Intentar realizar una operación que puede generar un error<br>
                    &emsp;int resultado = dividir(10, 0);<br>
                    } catch (Error e) {<br>
                    &emsp;// Manejar el error<br>
                    &emsp;printf("Ocurrió un error: %s\n", e.mensaje);<br>
                    }
                </p>
                <p>Este código demuestra el uso de estructuras de control if-else para tomar decisiones, for para repetir tareas y try-catch para manejar errores.</p>
            </div>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Variables y tipos de datos</h3>
            <p>Las variables y los tipos de datos son elementos fundamentales en la programación procedimental. Las variables se utilizan para almacenar valores, y los tipos de datos definen el tipo de valores que pueden contener.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    // Declaración de variables y asignación de valores<br>
                    int edad = 30;<br>
                    float altura = 1.75;<br>
                    char inicial = 'J';<br>
                    bool es_mayor_de_edad = verdadero;<br><br>

                    // Uso de variables y tipos de datos<br>
                    printf("Edad: %d\n", edad);<br>
                    printf("Altura: %.2f\n", altura);<br>
                    printf("Inicial: %c\n", inicial);<br>
                    printf("¿Es mayor de edad? %s\n", es_mayor_de_edad ? "Sí" : "No");<br>
                </p>
                <p>Este código demuestra la declaración y uso de variables con diferentes tipos de datos, como enteros, flotantes, caracteres y booleanos.</p>
            </div>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Modularidad y reutilización de código</h3>
            <p>La modularidad y la reutilización de código son aspectos importantes en la programación procedimental. Estos conceptos permiten dividir un programa en partes más pequeñas y manejables, y reutilizar esas partes en diferentes partes del programa.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    // Definición de una función que suma dos números<br>
                    int sumar(int a, int b) {<br>
                    &emsp;return a + b;<br>
                    }<br><br>

                    // Definición de un procedimiento que imprime un mensaje<br>
                    void imprimir_mensaje() {<br>
                    &emsp;printf("¡Hola, mundo!\n");<br>
                    }<br><br>

                    // Llamada a la función sumar y al procedimiento imprimir_mensaje<br>
                    int resultado = sumar(5, 3);<br>
                    imprimir_mensaje();<br>
                </p>
                <p>Este código demuestra la definición y llamada de una función que suma dos números y un procedimiento que imprime un mensaje, lo que permite reutilizar el código en diferentes partes del programa.</p>
            </div>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Manejo de memoria y rendimiento</h3>
            <p>El manejo de memoria y el rendimiento son aspectos críticos en la programación procedimental. Estos conceptos permiten garantizar que un programa utilice eficientemente los recursos del sistema y responda de manera rápida y eficiente a las acciones del usuario.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    // Declaración de un puntero y asignación de memoria<br>
                    int *puntero = (int *)malloc(sizeof(int));<br>
                    *puntero = 10;<br><br>

                    // Liberación de memoria<br>
                    free(puntero);<br>
                </p>
                <p>Este código demuestra la declaración de un puntero y la asignación de memoria, así como la liberación de memoria para garantizar un manejo eficiente de los recursos del sistema.</p>
            </div>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Modularidad</h3>
            <p>La modularidad es el proceso de dividir un programa en partes más pequeñas y manejables. En la programación procedimental, la modularidad se logra mediante el uso de funciones y procedimientos para estructurar y reutilizar el código.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    #include <stdio.h><br><br>

                        // Declaración de una función<br>
                        int sumar(int a, int b) {<br>
                        &emsp;return a + b;<br>
                        }<br><br>

                        int main() {<br>
                        &emsp;// Llamada a la función<br>
                        &emsp;int resultado = sumar(5, 3);<br>
                        &emsp;printf("El resultado es: %d\n", resultado);<br>
                        &emsp;return 0;<br>
                        }

                        // Módulo para calcular el área del círculo
                        double calcularArea(double radio) {
                        return 3.14159 * radio * radio;
                        }

                        // Módulo para imprimir el resultado
                        void imprimirResultado(double area) {
                        printf("El área del círculo es: %f\n", area);
                        }

                        int main() {
                        double radio = 5.0;
                        double area;

                        // Calcular el área del círculo
                        area = calcularArea(radio);

                        // Imprimir el resultado
                        imprimirResultado(area);

                        return 0;
                        }

                </p>
                <p>Este ejemplo ilustra cómo dividir un programa en módulos más pequeños y específicos, cada uno realizando una tarea bien definida. Esto mejora la legibilidad, mantenimiento y reutilización del código.</p>
            </div>
            <hr>
            <h3 class="mt-2 p-4 bg-white rounded shadow-md border border-dark">Programación imperativa</h3>
            <p>La programación imperativa es un paradigma de programación que se basa en la descripción detallada de cómo se deben llevar a cabo las operaciones paso a paso. En este enfoque, el programador especifica explícitamente los pasos que debe seguir el programa para alcanzar un resultado deseado. Los lenguajes de programación procedimentales, como C, son ejemplos comunes de lenguajes que siguen este paradigma.</p>
            <div class="mb-2 overflow-hidden rounded-lg shadow-md p-2 bg-gray-100">
                <p class="text-sm font-mono">
                    #include <stdio.h><br><br>

                        // Declaración de una función<br>
                        int sumar(int a, int b) {<br>
                        &emsp;return a + b;<br>
                        }<br><br>

                        int main() {<br>
                        &emsp;// Llamada a la función<br>
                        &emsp;int resultado = sumar(5, 3);<br>
                        &emsp;printf("El resultado es: %d\n", resultado);<br>
                        &emsp;return 0;<br>
                        }

                        int main() {
                        int numero;

                        // Solicitar al usuario que ingrese un número
                        printf("Por favor, ingrese un número entero: ");
                        scanf("%d", &numero);

                        // Verificar si el número es positivo, negativo o cero
                        if (numero > 0) {
                        printf("El número ingresado es positivo.\n");
                        } else if (numero < 0) {
                        printf("El número ingresado es negativo.\n");
                        } else {
                        printf("El número ingresado es cero.\n");
                        }

                        return 0;
                        }

                </p>
                <p>Este ejemplo ilustra cómo dividir un programa en módulos más pequeños y específicos, cada uno realizando una tarea bien definida. Esto mejora la legibilidad, mantenimiento y reutilización del código.</p>
            </div>
        </div>
    </div>
</div>
